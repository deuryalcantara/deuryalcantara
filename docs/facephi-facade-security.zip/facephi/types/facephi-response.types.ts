/**
 * Rutas del microservicio onboarding-micro-person.
 */
export const FacephiBackendUrls = {
  validateBiometric: '/api/v1/facephi/validate',
  validateFaceOnly: '/api/v1/facephi/validate-face',
  documentByIdT24: '/api/v1/facephi/document',
} as const;

/**
 * Respuesta cruda del microservicio (Facephi Identity Validation V2).
 * Uso interno del service: no se expone al consumidor del facade.
 */
export interface FacephiIdentityValidationResponse {
  serviceTransactionId: string;
  serviceResultCode: number;
  serviceResultLog: string;
  serviceTime: string;
  facialAuthenticationResult: number;
  facialAuthenticationLog: string;
  facialAuthenticationSimilarity: number;
  passiveLivenessResult: number;
  passiveLivenessLog: string;
}

/**
 * Respuesta pública del facade: sólo indica si la validación biométrica pasó.
 * El detalle de los códigos de Facephi queda en los logs del microservicio.
 */
export interface ValidateBiometricResponse {
  isValid: boolean;
}

/**
 * Indica si el cliente ya tiene el token del documento almacenado.
 * Determina si la app puede usar validate-face en lugar del flujo completo.
 */
export interface FacephiDocumentResponse {
  hasDocument: boolean;
  documentType: string | null;
}
